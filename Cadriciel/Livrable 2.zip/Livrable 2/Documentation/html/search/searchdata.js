var indexSectionsWithContent =
{
  0: "_abcdefgijlmnopqrstuvz~",
  1: "abcefijmnptuv",
  2: "im",
  3: "abcfimnptuv",
  4: "_acdefgilmnopqrstuvz~",
  5: "acemnprstv",
  6: "c",
  7: "i",
  8: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Modules",
  8: "Pages"
};

