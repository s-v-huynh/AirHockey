var searchData=
[
  ['_5f_5fdeclspec',['__declspec',['../group__inf2990.html#gab7f5f39b522334aa53af43ba21a16719',1,'FacadeInterfaceNative.cpp']]]
];
